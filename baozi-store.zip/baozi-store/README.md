# Baozi Store - API REST

API REST simples para controle de clientes, produtos e pedidos da Baozi Store (pão chinês).

**Tecnologias:** Java 17, Spring Boot 3, Spring Data JPA, H2 (ou MySQL), Maven, Postman.

## Como executar
```bash
mvn spring-boot:run
```
A API sobe em `http://localhost:8080`. Console do banco (H2): `http://localhost:8080/h2-console`
(JDBC URL: `jdbc:h2:file:./data/baozidb`, usuário `sa`, senha vazia).

Para usar MySQL, edite `src/main/resources/application.properties` (instruções no próprio arquivo).

## Endpoints
| Recurso | POST | GET (todos) | GET /{id} | PUT /{id} | DELETE /{id} |
|---|---|---|---|---|---|
| `/clientes` | ✔ | ✔ | ✔ | ✔ | ✔ |
| `/produtos` | ✔ | ✔ | ✔ | ✔ | ✔ |
| `/pedidos`  | ✔ | ✔ | ✔ | ✔ | ✔ |

## Exemplos de JSON
Cliente: `{"nome": "Jonathan5115166", "clienteDesde": "2026-10-12"}`
Produto: `{"nome": "Baozi de Carne", "preco": 8.50, "estoque": true}`
Pedido:  `{"cliente": {"id": 1}, "produto": {"id": 1}, "quantidade": 10}`
